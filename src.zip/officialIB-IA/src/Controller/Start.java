package Controller;

public class Start {

	
	public static void main(String[] args) {
		UserController theUserController = new UserController();
		
		System.out.println("difdb");
		theUserController.setUp();
		
	

	}

}
